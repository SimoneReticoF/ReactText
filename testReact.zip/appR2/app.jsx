import React, { useState, useEffect } from 'react';
import {
  Typography,
  TextField,
  Button,
  Grid,
  Container,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  root: {
    marginTop: theme.spacing(4),
  },
  inputContainer: {
    marginBottom: theme.spacing(2),
  },
  noteContainer: {
    marginBottom: theme.spacing(4),
  },
  noteItem: {
    marginBottom: theme.spacing(2),
  },
}));

const hardcodedNotes = [
  { day: 7, note: "imparare Svelte" },
  { day: 10, note: "creare Vite 2.0" },
  { day: 16, note: "sistemare cicalino" },
  { day: 22, note: "abolire le campane" },
  { day: 30, note: "meeting con la gang di Michele" },
];

const Note = ({ day, notes }) => {
  const classes = useStyles();

  return (
    <div className={classes.noteItem}>
      <Typography variant="h6" gutterBottom>{day}</Typography>
      {notes.map((note, index) => (
        <Typography key={index} variant="body1">{note.note}</Typography>
      ))}
    </div>
  );
};

const CalendarApp = () => {
  const classes = useStyles();
  const [day, setDay] = useState('');
  const [note, setNote] = useState('');
  const [notes, setNotes] = useState([]);

  const handleDayChange = (event) => {
    setDay(event.target.value);
  };

  const handleNoteChange = (event) => {
    setNote(event.target.value);
  };

  const handleInsertNote = () => {
    if (day && note) {
      const existingNote = notes.find((n) => n.day === parseInt(day));
      if (existingNote) {
        existingNote.note = note;
        setNotes([...notes]);
      } else {
        setNotes([...notes, { day: parseInt(day), note }]);
      }
      setDay('');
      setNote('');
    }
  };

  useEffect(() => {
    setNotes([...hardcodedNotes]);
  }, []);

  return (
    <Container className={classes.root}>
      <Typography variant="h4" gutterBottom>Calendario</Typography>
      <Grid container spacing={2} className={classes.inputContainer}>
        <Grid item xs={4}>
          <TextField
            type="number"
            label="Giorno"
            variant="outlined"
            value={day}
            onChange={handleDayChange}
            fullWidth
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            label="Nota"
            variant="outlined"
            value={note}
            onChange={handleNoteChange}
            fullWidth
          />
        </Grid>
        <Grid item xs={2}>
          <Button
            variant="contained"
            color="primary"
            onClick={handleInsertNote}
            fullWidth
          >
            Inserisci nota
          </Button>
        </Grid>
      </Grid>
      <div className={classes.noteContainer}>
        {Array.from({ length: 31 }, (_, index) => {
          const dayNumber = index + 1;
          const dayNotes = notes.filter((n) => n.day === dayNumber);
          return <Note key={dayNumber} day={dayNumber} notes={dayNotes} />;
        })}
      </div>
    </Container>
  );
};

export default CalendarApp;
