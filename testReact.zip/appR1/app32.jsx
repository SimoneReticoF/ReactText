import React from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import characters from './characters';

function HomePage() {
  return (
    <div>
      <h1>Personaggi famosi</h1>
      {characters.map((character) => (
        <div key={character.name}>
          <img src={character.image} alt={character.name} width="150" />
          <h2>{character.name}</h2>
          <Link to={`/char/${character.name}`}>More info</Link>
        </div>
      ))}
    </div>
  );
}

function CharacterDetailsPage({ match }) {
  const { charname } = match.params;
  const character = characters.find((char) => char.name === charname);

  if (!character) {
    return <div>Personaggio non trovato.</div>;
  }

  return (
    <div>
      <h1>{character.name}</h1>
      <img src={character.image} alt={character.name} width="300" />
      <p>{character.description}</p>
    </div>
  );
}

function App() {
  return (
    <Router>
      <header>
        <Link to="/">Home</Link>
      </header>
      <Switch>
        <Route exact path="/" component={HomePage} />
        <Route path="/char/:charname" component={CharacterDetailsPage} />
      </Switch>
    </Router>
  );
}

export default App;
